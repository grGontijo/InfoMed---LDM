package com.example.info_med

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
