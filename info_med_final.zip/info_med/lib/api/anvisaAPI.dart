import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;

class AnvisaApi {
  final _baseUrl = 'https://consultas.anvisa.gov.br/api';
  final _headers = {
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
    'authorization': 'Guest',
    'cache-control': 'no-cache',
    'if-modified-since': 'Mon, 26 Jul 1997 05:00:00 GMT',
    'pragma': 'no-cache',
    'referrer-policy': 'no-referrer-when-downgrade'
  };

  Future<String> searchMedicine(String name, {int page = 1}) async {
    final response = await http.get(
      Uri.parse(
          '$_baseUrl/consulta/bulario?count=1&filter%5BnomeProduto%5D=$name&page=$page'),
      headers: _headers,
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);

      // Acessando o valor de idBulaPacienteProtegido
      final content = data['content'];
      if (content != null && content.isNotEmpty) {
        final idBulaPacienteProtegido = content[0]['idBulaPacienteProtegido'];
        print(idBulaPacienteProtegido);
        return idBulaPacienteProtegido;
      } else {
        throw Exception('Content is empty or null');
      }
    } else {
      throw Exception('Failed to search for medicines');
    }
  }

  Future<Map<String, dynamic>> getMedicineDetails(String numProcesso) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/consulta/medicamento/produtos/$numProcesso'),
      headers: _headers,
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to fetch medicine details');
    }
  }

  Future<Uint8List> downloadBulaPdf(String idBulaProtegido) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/consulta/medicamentos/arquivo/bula/parecer/$idBulaProtegido/?Authorization='),
      headers: _headers,
    );


    if (response.statusCode == 200) {
      print(response);
      return response.bodyBytes;
    } else {
      print(response);
      throw Exception('Failed to download PDF');
    }
  }
}